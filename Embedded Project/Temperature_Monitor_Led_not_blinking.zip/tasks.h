#ifndef TASKS_H
#define TASKS_H
#include "main.h"
#include "queue.h"
#include "tasks.h"
#include "stm32l4xx_it.h"

void task_1_read_temperature(void);
void task_2_blink_leds(void);
void task_3_set_threshold(void);

#endif
